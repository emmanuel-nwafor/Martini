function image() {
  let img = document.querySelector("#image")
  img.style.width = 'auto'
  img.style.height = 'auto'
}